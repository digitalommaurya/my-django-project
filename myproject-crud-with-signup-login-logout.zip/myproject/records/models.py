from django.db import models
from django.contrib.auth.models import User  # import user

class Record(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    city = models.CharField(max_length=100)
    
    # NEW: track which user created this record
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.name