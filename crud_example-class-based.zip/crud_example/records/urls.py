from django.urls import path
from .views import *

urlpatterns = [
    path('', RecordListView.as_view(), name='record_list'),
    path('record/<int:pk>/', RecordDetailView.as_view(), name='record_detail'),
    path('record/new/', RecordCreateView.as_view(), name='record_create'),
    path('record/<int:pk>/edit/', RecordUpdateView.as_view(), name='record_update'),
    path('record/<int:pk>/delete/', RecordDeleteView.as_view(), name='record_delete'),
]