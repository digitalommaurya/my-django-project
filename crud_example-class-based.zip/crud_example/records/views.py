from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import Record

class RecordListView(ListView):
    model = Record
    template_name = 'records/record_list.html'
    context_object_name = 'records'

class RecordDetailView(DetailView):
    model = Record
    template_name = 'records/record_detail.html'

class RecordCreateView(CreateView):
    model = Record
    fields = ['name', 'city', 'phone']
    template_name = 'records/record_form.html'
    success_url = reverse_lazy('record_list')

class RecordUpdateView(UpdateView):
    model = Record
    fields = ['name', 'city', 'phone']
    template_name = 'records/record_form.html'
    success_url = reverse_lazy('record_list')

class RecordDeleteView(DeleteView):
    model = Record
    template_name = 'records/record_confirm_delete.html'
    success_url = reverse_lazy('record_list')