import React, { useEffect, useState } from 'react';
import api from '../api';
const StudentApp = () => {
 const [students, setStudents] = useState([]);
 const [form, setForm] = useState({ name: '', age: '', grade: '' });
 const [editId, setEditId] = useState(null);
 useEffect(() => {
 fetchStudents();
 }, []);
 const fetchStudents = async () => {
 const res = await api.get('students/');
 setStudents(res.data);
 };
 const handleChange = (e) => {
 setForm({ ...form, [e.target.name]: e.target.value });
 };
 const handleSubmit = async () => {
 if (editId) {
 await api.put(`students/${editId}/`, form);
 setEditId(null);
 } else {
 await api.post('students/', form);
 }
 setForm({ name: '', age: '', grade: '' });
 fetchStudents();
 };
 const handleEdit = (student) => {
 setForm({ name: student.name, age: student.age, grade: student.grade });
 setEditId(student.id);
 };
 const handleDelete = async (id) => {
 await api.delete(`students/${id}/`);
 fetchStudents();
 };
 return (
 <div style={{ padding: '20px' }}>
 <h2>Student Manager</h2>
 <input name="name" value={form.name} onChange={handleChange}
placeholder="Name" />
 <input name="age" type="number" value={form.age}
onChange={handleChange} placeholder="Age" />
 <input name="grade" value={form.grade} onChange={handleChange}
placeholder="Grade" />
 <button onClick={handleSubmit}>{editId ? 'Update' : 'Add'}</button>
 <ul>
 {students.map((s) => (
 <li key={s.id}>
 {s.name} (Age: {s.age}, Grade: {s.grade})
 <button onClick={() => handleEdit(s)}>Edit</button>
 <button onClick={() => handleDelete(s.id)}>Delete</button>
 </li>
 ))}
 </ul>
 </div>
 );
};
export default StudentApp;
