from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.decorators import login_required
from .forms import SignUpForm,RecordForm
from .models import Record


def signup_view(request):

    form = SignUpForm(request.POST or None)

    if form.is_valid():
        user = form.save()
        login(request,user)
        return redirect('dashboard')

    return render(request,'signup.html',{'form':form})


def login_view(request):

    if request.method == "POST":

        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request,username=username,password=password)

        if user:
            login(request,user)
            return redirect('dashboard')

    return render(request,'login.html')


def logout_view(request):

    logout(request)
    return redirect('login')


@login_required
def dashboard(request):

    records = Record.objects.filter(user=request.user)

    return render(request,'dashboard.html',{'records':records})


@login_required
def create_record(request):

    form = RecordForm(request.POST or None)

    if form.is_valid():

        record = form.save(commit=False)
        record.user = request.user
        record.save()

        return redirect('dashboard')

    return render(request,'form.html',{'form':form})


@login_required
def update_record(request,pk):

    record = get_object_or_404(Record,pk=pk,user=request.user)

    form = RecordForm(request.POST or None,instance=record)

    if form.is_valid():
        form.save()
        return redirect('dashboard')

    return render(request,'form.html',{'form':form})


@login_required
def delete_record(request,pk):

    record = get_object_or_404(Record,pk=pk,user=request.user)

    record.delete()

    return redirect('dashboard')