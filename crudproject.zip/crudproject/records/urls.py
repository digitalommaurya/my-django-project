from django.urls import path
from . import views

urlpatterns = [

path('',views.dashboard,name='dashboard'),

path('signup/',views.signup_view,name='signup'),
path('login/',views.login_view,name='login'),
path('logout/',views.logout_view,name='logout'),

path('create/',views.create_record,name='create'),
path('update/<int:pk>/',views.update_record,name='update'),
path('delete/<int:pk>/',views.delete_record,name='delete'),

]